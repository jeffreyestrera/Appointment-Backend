﻿using Context.Appointment.Entities;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Context.Appointment
{
    public class AppointmentContext : DbContext
    {
        //Entity
        public DbSet<Patient> Patient { get; set; }

        public AppointmentContext(DbContextOptions<AppointmentContext> options) : base(options) { }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            base.OnConfiguring(optionsBuilder);
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {

        }
    }
}
