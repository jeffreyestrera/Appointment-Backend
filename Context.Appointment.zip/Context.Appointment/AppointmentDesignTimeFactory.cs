﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Context.Appointment
{
    public class AppointmentDesignTimeFactory : IDesignTimeDbContextFactory<AppointmentContext>
    {
        public AppointmentContext CreateDbContext(string[] args)
        {
            var builder = new DbContextOptionsBuilder<AppointmentContext>();
            builder.UseSqlServer("Server=(local);Database=AppointmentDB; Trusted_Connection=True; MultipleActiveResultSets=true");
            return new AppointmentContext(builder.Options);
        }
    }
}
