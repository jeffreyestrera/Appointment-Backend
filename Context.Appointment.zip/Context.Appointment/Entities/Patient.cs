﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Context.Appointment.Entities
{
    public class Patient
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int PatientID { get; set; }

        [MaxLength(30)]
        public string PatientName { get; set; }

        [MaxLength(15)]
        public string Status { get; set; }

        public DateTime AppointmentSchedule { get; set; }
    }
}
