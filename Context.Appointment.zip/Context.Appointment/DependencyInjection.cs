﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Context.Appointment
{
    public static class DependencyInjection
    {
        public static void AddApplicationDbContext(this IServiceCollection services)
        {
            var configuration = services.BuildServiceProvider().GetService<IConfiguration>();

            services.AddDbContext<AppointmentContext>(options => {
                var conn = configuration.GetConnectionString("DefaultConnection");

                options.UseSqlServer(conn, sql => sql
                    .MigrationsAssembly("Context.Appointment")
                    .EnableRetryOnFailure());
            });
        }
    }
}
